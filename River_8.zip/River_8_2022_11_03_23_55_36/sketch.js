
var img;
var img2;
var msg = "why the hell does the image never load I followed the examples and everything I am baffled";

function preload() {
	img = loadImage("clouds.png");
    img2 = loadImage("transparent_legs.png");
}

function setup () {

	createCanvas(500, 500);
  
    textFont("Helvetica");

	fill(0);

	stroke(255);

}

function draw () {

	background(220);

  image(img, 0, 0,100,100);
  image(img2, mouseX, mouseY);

    textSize(20);

	text(msg, 200, 200, 200, 200);
}