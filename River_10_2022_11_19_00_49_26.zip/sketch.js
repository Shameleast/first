let video;

function setup() {

  noCanvas();

  video = createVideo(
    ['assets/sample1.webm','assets/sample2.webm','assets/sample3.webm']

  );

  video.size(1000, 600);
}

// This function is called when the video loads
function vidLoad() {
  video.play();
}

