function setup() {
  createCanvas(400, 400);
  print("thats alot of lightning!");
}

function draw() {
  angleMode(DEGREES);
  background(220);
  for (var x = 20; x < width + 50; x += 50) {
  lightning(200,200);
    translate(40,40);
    scale(0.9);
    rotate(PI*5.0);
  lightning(200,200);
  }
}
function lightning(x,y){//makes a bolt of lightning
  
    push();
	translate(x, y);
	strokeWeight(5);
	line(-25, 50, 0, 0);
    line(30,0,0,-0);
    line(10,40,30,0);
    line(25,40,10,40);
    line(25,40,-10,100);
    line(-10,100,-5,50);
    line(-5,50,-25,50)
	pop(); 
}